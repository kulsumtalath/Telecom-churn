#  CASE STUDY :Customer Churn Management for a Telecom Operator


```python
import numpy as np
import pandas as pd
import matplotlib.pyplot as plt
```


```python
data=pd.read_csv("WA_Fn-UseC_-Telco-Customer-Churn.csv")
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>gender</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>InternetService</th>
      <th>OnlineSecurity</th>
      <th>...</th>
      <th>DeviceProtection</th>
      <th>TechSupport</th>
      <th>StreamingTV</th>
      <th>StreamingMovies</th>
      <th>Contract</th>
      <th>PaperlessBilling</th>
      <th>PaymentMethod</th>
      <th>MonthlyCharges</th>
      <th>TotalCharges</th>
      <th>Churn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7590-VHVEG</td>
      <td>Female</td>
      <td>0</td>
      <td>Yes</td>
      <td>No</td>
      <td>1</td>
      <td>No</td>
      <td>No phone service</td>
      <td>DSL</td>
      <td>No</td>
      <td>...</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>Month-to-month</td>
      <td>Yes</td>
      <td>Electronic check</td>
      <td>29.85</td>
      <td>29.85</td>
      <td>No</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5575-GNVDE</td>
      <td>Male</td>
      <td>0</td>
      <td>No</td>
      <td>No</td>
      <td>34</td>
      <td>Yes</td>
      <td>No</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>One year</td>
      <td>No</td>
      <td>Mailed check</td>
      <td>56.95</td>
      <td>1889.5</td>
      <td>No</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3668-QPYBK</td>
      <td>Male</td>
      <td>0</td>
      <td>No</td>
      <td>No</td>
      <td>2</td>
      <td>Yes</td>
      <td>No</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>Month-to-month</td>
      <td>Yes</td>
      <td>Mailed check</td>
      <td>53.85</td>
      <td>108.15</td>
      <td>Yes</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7795-CFOCW</td>
      <td>Male</td>
      <td>0</td>
      <td>No</td>
      <td>No</td>
      <td>45</td>
      <td>No</td>
      <td>No phone service</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>One year</td>
      <td>No</td>
      <td>Bank transfer (automatic)</td>
      <td>42.30</td>
      <td>1840.75</td>
      <td>No</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9237-HQITU</td>
      <td>Female</td>
      <td>0</td>
      <td>No</td>
      <td>No</td>
      <td>2</td>
      <td>Yes</td>
      <td>No</td>
      <td>Fiber optic</td>
      <td>No</td>
      <td>...</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>Month-to-month</td>
      <td>Yes</td>
      <td>Electronic check</td>
      <td>70.70</td>
      <td>151.65</td>
      <td>Yes</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
data.columns
```




    Index(['customerID', 'gender', 'SeniorCitizen', 'Partner', 'Dependents',
           'tenure', 'PhoneService', 'MultipleLines', 'InternetService',
           'OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport',
           'StreamingTV', 'StreamingMovies', 'Contract', 'PaperlessBilling',
           'PaymentMethod', 'MonthlyCharges', 'TotalCharges', 'Churn'],
          dtype='object')



Objective -- to predict whether a customer will churn or not..
Target variable -- churn
Problem -- classification -- logistic regression
steps
1 Data cleaning and preparation --handle missing,one hot encoding,EDA
2 feature selection
3 model building--train_test_split,model creation
4 model evaluation--confusion matrix,accuracy,precision and recall

# Data Cleaning and Data Preparation


```python
data.shape
```




    (7043, 21)




```python
data.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>gender</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>InternetService</th>
      <th>OnlineSecurity</th>
      <th>...</th>
      <th>DeviceProtection</th>
      <th>TechSupport</th>
      <th>StreamingTV</th>
      <th>StreamingMovies</th>
      <th>Contract</th>
      <th>PaperlessBilling</th>
      <th>PaymentMethod</th>
      <th>MonthlyCharges</th>
      <th>TotalCharges</th>
      <th>Churn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7038</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7039</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7040</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7041</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7042</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>7043 rows × 21 columns</p>
</div>




```python
data.isnull().sum()
```




    customerID          0
    gender              0
    SeniorCitizen       0
    Partner             0
    Dependents          0
    tenure              0
    PhoneService        0
    MultipleLines       0
    InternetService     0
    OnlineSecurity      0
    OnlineBackup        0
    DeviceProtection    0
    TechSupport         0
    StreamingTV         0
    StreamingMovies     0
    Contract            0
    PaperlessBilling    0
    PaymentMethod       0
    MonthlyCharges      0
    TotalCharges        0
    Churn               0
    dtype: int64




```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7043 entries, 0 to 7042
    Data columns (total 21 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   customerID        7043 non-null   object 
     1   gender            7043 non-null   object 
     2   SeniorCitizen     7043 non-null   int64  
     3   Partner           7043 non-null   object 
     4   Dependents        7043 non-null   object 
     5   tenure            7043 non-null   int64  
     6   PhoneService      7043 non-null   object 
     7   MultipleLines     7043 non-null   object 
     8   InternetService   7043 non-null   object 
     9   OnlineSecurity    7043 non-null   object 
     10  OnlineBackup      7043 non-null   object 
     11  DeviceProtection  7043 non-null   object 
     12  TechSupport       7043 non-null   object 
     13  StreamingTV       7043 non-null   object 
     14  StreamingMovies   7043 non-null   object 
     15  Contract          7043 non-null   object 
     16  PaperlessBilling  7043 non-null   object 
     17  PaymentMethod     7043 non-null   object 
     18  MonthlyCharges    7043 non-null   float64
     19  TotalCharges      7043 non-null   object 
     20  Churn             7043 non-null   object 
    dtypes: float64(1), int64(2), object(18)
    memory usage: 1.1+ MB
    


```python
data.describe()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SeniorCitizen</th>
      <th>tenure</th>
      <th>MonthlyCharges</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>count</th>
      <td>7043.000000</td>
      <td>7043.000000</td>
      <td>7043.000000</td>
    </tr>
    <tr>
      <th>mean</th>
      <td>0.162147</td>
      <td>32.371149</td>
      <td>64.761692</td>
    </tr>
    <tr>
      <th>std</th>
      <td>0.368612</td>
      <td>24.559481</td>
      <td>30.090047</td>
    </tr>
    <tr>
      <th>min</th>
      <td>0.000000</td>
      <td>0.000000</td>
      <td>18.250000</td>
    </tr>
    <tr>
      <th>25%</th>
      <td>0.000000</td>
      <td>9.000000</td>
      <td>35.500000</td>
    </tr>
    <tr>
      <th>50%</th>
      <td>0.000000</td>
      <td>29.000000</td>
      <td>70.350000</td>
    </tr>
    <tr>
      <th>75%</th>
      <td>0.000000</td>
      <td>55.000000</td>
      <td>89.850000</td>
    </tr>
    <tr>
      <th>max</th>
      <td>1.000000</td>
      <td>72.000000</td>
      <td>118.750000</td>
    </tr>
  </tbody>
</table>
</div>




```python
data.PhoneService.unique()
```




    array(['No', 'Yes'], dtype=object)




```python
data.PhoneService=data.PhoneService.map({'Yes':1,'No':0})
data.PhoneService
```




    0       0
    1       1
    2       1
    3       0
    4       1
           ..
    7038    1
    7039    1
    7040    0
    7041    1
    7042    1
    Name: PhoneService, Length: 7043, dtype: int64




```python
data.isnull()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>gender</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>InternetService</th>
      <th>OnlineSecurity</th>
      <th>...</th>
      <th>DeviceProtection</th>
      <th>TechSupport</th>
      <th>StreamingTV</th>
      <th>StreamingMovies</th>
      <th>Contract</th>
      <th>PaperlessBilling</th>
      <th>PaymentMethod</th>
      <th>MonthlyCharges</th>
      <th>TotalCharges</th>
      <th>Churn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>1</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>2</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>3</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>4</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>7038</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7039</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7040</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7041</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
    <tr>
      <th>7042</th>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>...</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
      <td>False</td>
    </tr>
  </tbody>
</table>
<p>7043 rows × 21 columns</p>
</div>




```python
data.info()


```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7043 entries, 0 to 7042
    Data columns (total 21 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   customerID        7043 non-null   object 
     1   gender            7043 non-null   object 
     2   SeniorCitizen     7043 non-null   int64  
     3   Partner           7043 non-null   object 
     4   Dependents        7043 non-null   object 
     5   tenure            7043 non-null   int64  
     6   PhoneService      7043 non-null   int64  
     7   MultipleLines     7043 non-null   object 
     8   InternetService   7043 non-null   object 
     9   OnlineSecurity    7043 non-null   object 
     10  OnlineBackup      7043 non-null   object 
     11  DeviceProtection  7043 non-null   object 
     12  TechSupport       7043 non-null   object 
     13  StreamingTV       7043 non-null   object 
     14  StreamingMovies   7043 non-null   object 
     15  Contract          7043 non-null   object 
     16  PaperlessBilling  7043 non-null   object 
     17  PaymentMethod     7043 non-null   object 
     18  MonthlyCharges    7043 non-null   float64
     19  TotalCharges      7043 non-null   object 
     20  Churn             7043 non-null   object 
    dtypes: float64(1), int64(3), object(17)
    memory usage: 1.1+ MB
    


```python
data.PaymentMethod.unique()
```




    array(['Electronic check', 'Mailed check', 'Bank transfer (automatic)',
           'Credit card (automatic)'], dtype=object)




```python

```


```python
for v in data.columns:
    print(v,'-->',data[v].unique())
```

    customerID --> ['7590-VHVEG' '5575-GNVDE' '3668-QPYBK' ... '4801-JZAZL' '8361-LTMKD'
     '3186-AJIEK']
    gender --> ['Female' 'Male']
    SeniorCitizen --> [0 1]
    Partner --> ['Yes' 'No']
    Dependents --> ['No' 'Yes']
    tenure --> [ 1 34  2 45  8 22 10 28 62 13 16 58 49 25 69 52 71 21 12 30 47 72 17 27
      5 46 11 70 63 43 15 60 18 66  9  3 31 50 64 56  7 42 35 48 29 65 38 68
     32 55 37 36 41  6  4 33 67 23 57 61 14 20 53 40 59 24 44 19 54 51 26  0
     39]
    PhoneService --> [0 1]
    MultipleLines --> ['No phone service' 'No' 'Yes']
    InternetService --> ['DSL' 'Fiber optic' 'No']
    OnlineSecurity --> ['No' 'Yes' 'No internet service']
    OnlineBackup --> ['Yes' 'No' 'No internet service']
    DeviceProtection --> ['No' 'Yes' 'No internet service']
    TechSupport --> ['No' 'Yes' 'No internet service']
    StreamingTV --> ['No' 'Yes' 'No internet service']
    StreamingMovies --> ['No' 'Yes' 'No internet service']
    Contract --> ['Month-to-month' 'One year' 'Two year']
    PaperlessBilling --> ['Yes' 'No']
    PaymentMethod --> ['Electronic check' 'Mailed check' 'Bank transfer (automatic)'
     'Credit card (automatic)']
    MonthlyCharges --> [29.85 56.95 53.85 ... 63.1  44.2  78.7 ]
    TotalCharges --> ['29.85' '1889.5' '108.15' ... '346.45' '306.6' '6844.5']
    Churn --> ['No' 'Yes']
    


```python
vars=['PaperlessBilling','Partner','Churn','Dependents']
def bin_mapping(x):
    return x.map({'Yes':1,'No':0})
data[vars]=data[vars].apply(bin_mapping)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>gender</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>InternetService</th>
      <th>OnlineSecurity</th>
      <th>...</th>
      <th>DeviceProtection</th>
      <th>TechSupport</th>
      <th>StreamingTV</th>
      <th>StreamingMovies</th>
      <th>Contract</th>
      <th>PaperlessBilling</th>
      <th>PaymentMethod</th>
      <th>MonthlyCharges</th>
      <th>TotalCharges</th>
      <th>Churn</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7590-VHVEG</td>
      <td>Female</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>No phone service</td>
      <td>DSL</td>
      <td>No</td>
      <td>...</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>Month-to-month</td>
      <td>1</td>
      <td>Electronic check</td>
      <td>29.85</td>
      <td>29.85</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5575-GNVDE</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>34</td>
      <td>1</td>
      <td>No</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>One year</td>
      <td>0</td>
      <td>Mailed check</td>
      <td>56.95</td>
      <td>1889.5</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3668-QPYBK</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>Month-to-month</td>
      <td>1</td>
      <td>Mailed check</td>
      <td>53.85</td>
      <td>108.15</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7795-CFOCW</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>0</td>
      <td>No phone service</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>No</td>
      <td>No</td>
      <td>One year</td>
      <td>0</td>
      <td>Bank transfer (automatic)</td>
      <td>42.30</td>
      <td>1840.75</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9237-HQITU</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>Fiber optic</td>
      <td>No</td>
      <td>...</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>Month-to-month</td>
      <td>1</td>
      <td>Electronic check</td>
      <td>70.70</td>
      <td>151.65</td>
      <td>1</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 21 columns</p>
</div>




```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7043 entries, 0 to 7042
    Data columns (total 21 columns):
     #   Column            Non-Null Count  Dtype  
    ---  ------            --------------  -----  
     0   customerID        7043 non-null   object 
     1   gender            7043 non-null   object 
     2   SeniorCitizen     7043 non-null   int64  
     3   Partner           7043 non-null   int64  
     4   Dependents        7043 non-null   int64  
     5   tenure            7043 non-null   int64  
     6   PhoneService      7043 non-null   int64  
     7   MultipleLines     7043 non-null   object 
     8   InternetService   7043 non-null   object 
     9   OnlineSecurity    7043 non-null   object 
     10  OnlineBackup      7043 non-null   object 
     11  DeviceProtection  7043 non-null   object 
     12  TechSupport       7043 non-null   object 
     13  StreamingTV       7043 non-null   object 
     14  StreamingMovies   7043 non-null   object 
     15  Contract          7043 non-null   object 
     16  PaperlessBilling  7043 non-null   int64  
     17  PaymentMethod     7043 non-null   object 
     18  MonthlyCharges    7043 non-null   float64
     19  TotalCharges      7043 non-null   object 
     20  Churn             7043 non-null   int64  
    dtypes: float64(1), int64(7), object(13)
    memory usage: 1.1+ MB
    


```python
#for converting categorical use one hot coding
```


```python
d1=pd.get_dummies(data[['Contract','PaymentMethod','gender','InternetService']],drop_first=True)
d1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Contract_One year</th>
      <th>Contract_Two year</th>
      <th>PaymentMethod_Credit card (automatic)</th>
      <th>PaymentMethod_Electronic check</th>
      <th>PaymentMethod_Mailed check</th>
      <th>gender_Male</th>
      <th>InternetService_Fiber optic</th>
      <th>InternetService_No</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
data=pd.concat([data,d1],axis=1)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>gender</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>InternetService</th>
      <th>OnlineSecurity</th>
      <th>...</th>
      <th>TotalCharges</th>
      <th>Churn</th>
      <th>Contract_One year</th>
      <th>Contract_Two year</th>
      <th>PaymentMethod_Credit card (automatic)</th>
      <th>PaymentMethod_Electronic check</th>
      <th>PaymentMethod_Mailed check</th>
      <th>gender_Male</th>
      <th>InternetService_Fiber optic</th>
      <th>InternetService_No</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7590-VHVEG</td>
      <td>Female</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>No phone service</td>
      <td>DSL</td>
      <td>No</td>
      <td>...</td>
      <td>29.85</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5575-GNVDE</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>34</td>
      <td>1</td>
      <td>No</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>1889.5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3668-QPYBK</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>108.15</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7795-CFOCW</td>
      <td>Male</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>0</td>
      <td>No phone service</td>
      <td>DSL</td>
      <td>Yes</td>
      <td>...</td>
      <td>1840.75</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9237-HQITU</td>
      <td>Female</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>Fiber optic</td>
      <td>No</td>
      <td>...</td>
      <td>151.65</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 29 columns</p>
</div>




```python
data.drop(['Contract','PaymentMethod','gender','InternetService'],axis=1,inplace=True)

```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>OnlineSecurity</th>
      <th>OnlineBackup</th>
      <th>DeviceProtection</th>
      <th>...</th>
      <th>TotalCharges</th>
      <th>Churn</th>
      <th>Contract_One year</th>
      <th>Contract_Two year</th>
      <th>PaymentMethod_Credit card (automatic)</th>
      <th>PaymentMethod_Electronic check</th>
      <th>PaymentMethod_Mailed check</th>
      <th>gender_Male</th>
      <th>InternetService_Fiber optic</th>
      <th>InternetService_No</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7590-VHVEG</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>No phone service</td>
      <td>No</td>
      <td>Yes</td>
      <td>No</td>
      <td>...</td>
      <td>29.85</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5575-GNVDE</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>34</td>
      <td>1</td>
      <td>No</td>
      <td>Yes</td>
      <td>No</td>
      <td>Yes</td>
      <td>...</td>
      <td>1889.5</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3668-QPYBK</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>No</td>
      <td>...</td>
      <td>108.15</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7795-CFOCW</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>0</td>
      <td>No phone service</td>
      <td>Yes</td>
      <td>No</td>
      <td>Yes</td>
      <td>...</td>
      <td>1840.75</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9237-HQITU</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>...</td>
      <td>151.65</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 25 columns</p>
</div>




```python
m1=pd.get_dummies(data['MultipleLines'],prefix="MultipleLines")
```


```python
m1.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>MultipleLines_No</th>
      <th>MultipleLines_No phone service</th>
      <th>MultipleLines_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
m1.drop("MultipleLines_No phone service",axis=1,inplace=True)
```


```python
data=pd.concat([data,m1],axis=1)
data.columns
```




    Index(['customerID', 'SeniorCitizen', 'Partner', 'Dependents', 'tenure',
           'PhoneService', 'MultipleLines', 'OnlineSecurity', 'OnlineBackup',
           'DeviceProtection', 'TechSupport', 'StreamingTV', 'StreamingMovies',
           'PaperlessBilling', 'MonthlyCharges', 'TotalCharges', 'Churn',
           'Contract_One year', 'Contract_Two year',
           'PaymentMethod_Credit card (automatic)',
           'PaymentMethod_Electronic check', 'PaymentMethod_Mailed check',
           'gender_Male', 'InternetService_Fiber optic', 'InternetService_No',
           'MultipleLines_No', 'MultipleLines_Yes'],
          dtype='object')




```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>OnlineSecurity</th>
      <th>OnlineBackup</th>
      <th>DeviceProtection</th>
      <th>...</th>
      <th>Contract_One year</th>
      <th>Contract_Two year</th>
      <th>PaymentMethod_Credit card (automatic)</th>
      <th>PaymentMethod_Electronic check</th>
      <th>PaymentMethod_Mailed check</th>
      <th>gender_Male</th>
      <th>InternetService_Fiber optic</th>
      <th>InternetService_No</th>
      <th>MultipleLines_No</th>
      <th>MultipleLines_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7590-VHVEG</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>No phone service</td>
      <td>No</td>
      <td>Yes</td>
      <td>No</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5575-GNVDE</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>34</td>
      <td>1</td>
      <td>No</td>
      <td>Yes</td>
      <td>No</td>
      <td>Yes</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3668-QPYBK</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>No</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7795-CFOCW</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>0</td>
      <td>No phone service</td>
      <td>Yes</td>
      <td>No</td>
      <td>Yes</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9237-HQITU</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 27 columns</p>
</div>




```python
for var in ['OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV']:
    m2=pd.get_dummies(data[var],prefix=var)
    data=pd.concat([data,m2],axis=1)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>OnlineSecurity</th>
      <th>OnlineBackup</th>
      <th>DeviceProtection</th>
      <th>...</th>
      <th>OnlineBackup_Yes</th>
      <th>DeviceProtection_No</th>
      <th>DeviceProtection_No internet service</th>
      <th>DeviceProtection_Yes</th>
      <th>TechSupport_No</th>
      <th>TechSupport_No internet service</th>
      <th>TechSupport_Yes</th>
      <th>StreamingTV_No</th>
      <th>StreamingTV_No internet service</th>
      <th>StreamingTV_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7590-VHVEG</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>No phone service</td>
      <td>No</td>
      <td>Yes</td>
      <td>No</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5575-GNVDE</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>34</td>
      <td>1</td>
      <td>No</td>
      <td>Yes</td>
      <td>No</td>
      <td>Yes</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3668-QPYBK</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>Yes</td>
      <td>Yes</td>
      <td>No</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7795-CFOCW</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>0</td>
      <td>No phone service</td>
      <td>Yes</td>
      <td>No</td>
      <td>Yes</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9237-HQITU</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>No</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 42 columns</p>
</div>




```python
data.drop(['OnlineSecurity', 'OnlineBackup', 'DeviceProtection', 'TechSupport', 'StreamingTV'],axis=1,inplace=True)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>StreamingMovies</th>
      <th>PaperlessBilling</th>
      <th>MonthlyCharges</th>
      <th>...</th>
      <th>OnlineBackup_Yes</th>
      <th>DeviceProtection_No</th>
      <th>DeviceProtection_No internet service</th>
      <th>DeviceProtection_Yes</th>
      <th>TechSupport_No</th>
      <th>TechSupport_No internet service</th>
      <th>TechSupport_Yes</th>
      <th>StreamingTV_No</th>
      <th>StreamingTV_No internet service</th>
      <th>StreamingTV_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7590-VHVEG</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>No phone service</td>
      <td>No</td>
      <td>1</td>
      <td>29.85</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5575-GNVDE</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>34</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>0</td>
      <td>56.95</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3668-QPYBK</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>1</td>
      <td>53.85</td>
      <td>...</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7795-CFOCW</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>0</td>
      <td>No phone service</td>
      <td>No</td>
      <td>0</td>
      <td>42.30</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9237-HQITU</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>1</td>
      <td>70.70</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 37 columns</p>
</div>




```python
data.columns
```




    Index(['customerID', 'SeniorCitizen', 'Partner', 'Dependents', 'tenure',
           'PhoneService', 'MultipleLines', 'StreamingMovies', 'PaperlessBilling',
           'MonthlyCharges', 'TotalCharges', 'Churn', 'Contract_One year',
           'Contract_Two year', 'PaymentMethod_Credit card (automatic)',
           'PaymentMethod_Electronic check', 'PaymentMethod_Mailed check',
           'gender_Male', 'InternetService_Fiber optic', 'InternetService_No',
           'MultipleLines_No', 'MultipleLines_Yes', 'OnlineSecurity_No',
           'OnlineSecurity_No internet service', 'OnlineSecurity_Yes',
           'OnlineBackup_No', 'OnlineBackup_No internet service',
           'OnlineBackup_Yes', 'DeviceProtection_No',
           'DeviceProtection_No internet service', 'DeviceProtection_Yes',
           'TechSupport_No', 'TechSupport_No internet service', 'TechSupport_Yes',
           'StreamingTV_No', 'StreamingTV_No internet service', 'StreamingTV_Yes'],
          dtype='object')




```python
data.drop(['OnlineSecurity_No internet service','OnlineBackup_No internet service','DeviceProtection_No internet service','TechSupport_No internet service','StreamingTV_No internet service'],axis=1,inplace=True)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>customerID</th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>MultipleLines</th>
      <th>StreamingMovies</th>
      <th>PaperlessBilling</th>
      <th>MonthlyCharges</th>
      <th>...</th>
      <th>OnlineSecurity_No</th>
      <th>OnlineSecurity_Yes</th>
      <th>OnlineBackup_No</th>
      <th>OnlineBackup_Yes</th>
      <th>DeviceProtection_No</th>
      <th>DeviceProtection_Yes</th>
      <th>TechSupport_No</th>
      <th>TechSupport_Yes</th>
      <th>StreamingTV_No</th>
      <th>StreamingTV_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>7590-VHVEG</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>No phone service</td>
      <td>No</td>
      <td>1</td>
      <td>29.85</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>5575-GNVDE</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>34</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>0</td>
      <td>56.95</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>3668-QPYBK</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>1</td>
      <td>53.85</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>7795-CFOCW</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>0</td>
      <td>No phone service</td>
      <td>No</td>
      <td>0</td>
      <td>42.30</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>9237-HQITU</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>No</td>
      <td>No</td>
      <td>1</td>
      <td>70.70</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 32 columns</p>
</div>




```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7043 entries, 0 to 7042
    Data columns (total 32 columns):
     #   Column                                 Non-Null Count  Dtype  
    ---  ------                                 --------------  -----  
     0   customerID                             7043 non-null   object 
     1   SeniorCitizen                          7043 non-null   int64  
     2   Partner                                7043 non-null   int64  
     3   Dependents                             7043 non-null   int64  
     4   tenure                                 7043 non-null   int64  
     5   PhoneService                           7043 non-null   int64  
     6   MultipleLines                          7043 non-null   object 
     7   StreamingMovies                        7043 non-null   object 
     8   PaperlessBilling                       7043 non-null   int64  
     9   MonthlyCharges                         7043 non-null   float64
     10  TotalCharges                           7043 non-null   object 
     11  Churn                                  7043 non-null   int64  
     12  Contract_One year                      7043 non-null   uint8  
     13  Contract_Two year                      7043 non-null   uint8  
     14  PaymentMethod_Credit card (automatic)  7043 non-null   uint8  
     15  PaymentMethod_Electronic check         7043 non-null   uint8  
     16  PaymentMethod_Mailed check             7043 non-null   uint8  
     17  gender_Male                            7043 non-null   uint8  
     18  InternetService_Fiber optic            7043 non-null   uint8  
     19  InternetService_No                     7043 non-null   uint8  
     20  MultipleLines_No                       7043 non-null   uint8  
     21  MultipleLines_Yes                      7043 non-null   uint8  
     22  OnlineSecurity_No                      7043 non-null   uint8  
     23  OnlineSecurity_Yes                     7043 non-null   uint8  
     24  OnlineBackup_No                        7043 non-null   uint8  
     25  OnlineBackup_Yes                       7043 non-null   uint8  
     26  DeviceProtection_No                    7043 non-null   uint8  
     27  DeviceProtection_Yes                   7043 non-null   uint8  
     28  TechSupport_No                         7043 non-null   uint8  
     29  TechSupport_Yes                        7043 non-null   uint8  
     30  StreamingTV_No                         7043 non-null   uint8  
     31  StreamingTV_Yes                        7043 non-null   uint8  
    dtypes: float64(1), int64(7), object(4), uint8(20)
    memory usage: 798.0+ KB
    


```python
data.drop(['customerID','MultipleLines','StreamingMovies'],axis=1,inplace=True)
```


```python
data.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>PaperlessBilling</th>
      <th>MonthlyCharges</th>
      <th>TotalCharges</th>
      <th>Churn</th>
      <th>Contract_One year</th>
      <th>...</th>
      <th>OnlineSecurity_No</th>
      <th>OnlineSecurity_Yes</th>
      <th>OnlineBackup_No</th>
      <th>OnlineBackup_Yes</th>
      <th>DeviceProtection_No</th>
      <th>DeviceProtection_Yes</th>
      <th>TechSupport_No</th>
      <th>TechSupport_Yes</th>
      <th>StreamingTV_No</th>
      <th>StreamingTV_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>0</th>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>29.85</td>
      <td>29.85</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>34</td>
      <td>1</td>
      <td>0</td>
      <td>56.95</td>
      <td>1889.5</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>53.85</td>
      <td>108.15</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>45</td>
      <td>0</td>
      <td>0</td>
      <td>42.30</td>
      <td>1840.75</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>2</td>
      <td>1</td>
      <td>1</td>
      <td>70.70</td>
      <td>151.65</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 29 columns</p>
</div>




```python
data.TotalCharges
```




    0         29.85
    1        1889.5
    2        108.15
    3       1840.75
    4        151.65
             ...   
    7038     1990.5
    7039     7362.9
    7040     346.45
    7041      306.6
    7042     6844.5
    Name: TotalCharges, Length: 7043, dtype: object




```python
data.TotalCharges=pd.to_numeric(data.TotalCharges,errors='coerce')
```


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7043 entries, 0 to 7042
    Data columns (total 29 columns):
     #   Column                                 Non-Null Count  Dtype  
    ---  ------                                 --------------  -----  
     0   SeniorCitizen                          7043 non-null   int64  
     1   Partner                                7043 non-null   int64  
     2   Dependents                             7043 non-null   int64  
     3   tenure                                 7043 non-null   int64  
     4   PhoneService                           7043 non-null   int64  
     5   PaperlessBilling                       7043 non-null   int64  
     6   MonthlyCharges                         7043 non-null   float64
     7   TotalCharges                           7032 non-null   float64
     8   Churn                                  7043 non-null   int64  
     9   Contract_One year                      7043 non-null   uint8  
     10  Contract_Two year                      7043 non-null   uint8  
     11  PaymentMethod_Credit card (automatic)  7043 non-null   uint8  
     12  PaymentMethod_Electronic check         7043 non-null   uint8  
     13  PaymentMethod_Mailed check             7043 non-null   uint8  
     14  gender_Male                            7043 non-null   uint8  
     15  InternetService_Fiber optic            7043 non-null   uint8  
     16  InternetService_No                     7043 non-null   uint8  
     17  MultipleLines_No                       7043 non-null   uint8  
     18  MultipleLines_Yes                      7043 non-null   uint8  
     19  OnlineSecurity_No                      7043 non-null   uint8  
     20  OnlineSecurity_Yes                     7043 non-null   uint8  
     21  OnlineBackup_No                        7043 non-null   uint8  
     22  OnlineBackup_Yes                       7043 non-null   uint8  
     23  DeviceProtection_No                    7043 non-null   uint8  
     24  DeviceProtection_Yes                   7043 non-null   uint8  
     25  TechSupport_No                         7043 non-null   uint8  
     26  TechSupport_Yes                        7043 non-null   uint8  
     27  StreamingTV_No                         7043 non-null   uint8  
     28  StreamingTV_Yes                        7043 non-null   uint8  
    dtypes: float64(2), int64(7), uint8(20)
    memory usage: 632.9 KB
    


```python
data.isnull().sum()
```




    SeniorCitizen                             0
    Partner                                   0
    Dependents                                0
    tenure                                    0
    PhoneService                              0
    PaperlessBilling                          0
    MonthlyCharges                            0
    TotalCharges                             11
    Churn                                     0
    Contract_One year                         0
    Contract_Two year                         0
    PaymentMethod_Credit card (automatic)     0
    PaymentMethod_Electronic check            0
    PaymentMethod_Mailed check                0
    gender_Male                               0
    InternetService_Fiber optic               0
    InternetService_No                        0
    MultipleLines_No                          0
    MultipleLines_Yes                         0
    OnlineSecurity_No                         0
    OnlineSecurity_Yes                        0
    OnlineBackup_No                           0
    OnlineBackup_Yes                          0
    DeviceProtection_No                       0
    DeviceProtection_Yes                      0
    TechSupport_No                            0
    TechSupport_Yes                           0
    StreamingTV_No                            0
    StreamingTV_Yes                           0
    dtype: int64




```python
data=data.fillna(data.TotalCharges.mean())
```


```python
data.info()
```

    <class 'pandas.core.frame.DataFrame'>
    RangeIndex: 7043 entries, 0 to 7042
    Data columns (total 29 columns):
     #   Column                                 Non-Null Count  Dtype  
    ---  ------                                 --------------  -----  
     0   SeniorCitizen                          7043 non-null   int64  
     1   Partner                                7043 non-null   int64  
     2   Dependents                             7043 non-null   int64  
     3   tenure                                 7043 non-null   int64  
     4   PhoneService                           7043 non-null   int64  
     5   PaperlessBilling                       7043 non-null   int64  
     6   MonthlyCharges                         7043 non-null   float64
     7   TotalCharges                           7043 non-null   float64
     8   Churn                                  7043 non-null   int64  
     9   Contract_One year                      7043 non-null   uint8  
     10  Contract_Two year                      7043 non-null   uint8  
     11  PaymentMethod_Credit card (automatic)  7043 non-null   uint8  
     12  PaymentMethod_Electronic check         7043 non-null   uint8  
     13  PaymentMethod_Mailed check             7043 non-null   uint8  
     14  gender_Male                            7043 non-null   uint8  
     15  InternetService_Fiber optic            7043 non-null   uint8  
     16  InternetService_No                     7043 non-null   uint8  
     17  MultipleLines_No                       7043 non-null   uint8  
     18  MultipleLines_Yes                      7043 non-null   uint8  
     19  OnlineSecurity_No                      7043 non-null   uint8  
     20  OnlineSecurity_Yes                     7043 non-null   uint8  
     21  OnlineBackup_No                        7043 non-null   uint8  
     22  OnlineBackup_Yes                       7043 non-null   uint8  
     23  DeviceProtection_No                    7043 non-null   uint8  
     24  DeviceProtection_Yes                   7043 non-null   uint8  
     25  TechSupport_No                         7043 non-null   uint8  
     26  TechSupport_Yes                        7043 non-null   uint8  
     27  StreamingTV_No                         7043 non-null   uint8  
     28  StreamingTV_Yes                        7043 non-null   uint8  
    dtypes: float64(2), int64(7), uint8(20)
    memory usage: 632.9 KB
    


```python
data.isnull().sum()
```




    SeniorCitizen                            0
    Partner                                  0
    Dependents                               0
    tenure                                   0
    PhoneService                             0
    PaperlessBilling                         0
    MonthlyCharges                           0
    TotalCharges                             0
    Churn                                    0
    Contract_One year                        0
    Contract_Two year                        0
    PaymentMethod_Credit card (automatic)    0
    PaymentMethod_Electronic check           0
    PaymentMethod_Mailed check               0
    gender_Male                              0
    InternetService_Fiber optic              0
    InternetService_No                       0
    MultipleLines_No                         0
    MultipleLines_Yes                        0
    OnlineSecurity_No                        0
    OnlineSecurity_Yes                       0
    OnlineBackup_No                          0
    OnlineBackup_Yes                         0
    DeviceProtection_No                      0
    DeviceProtection_Yes                     0
    TechSupport_No                           0
    TechSupport_Yes                          0
    StreamingTV_No                           0
    StreamingTV_Yes                          0
    dtype: int64




```python
#data split
from sklearn.model_selection import train_test_split
```


```python
X=data.drop("Churn",axis=1)
y=data["Churn"]
X_train,X_test,y_train,y_test=train_test_split(X,y,test_size=0.3,random_state=42)
```


```python
X_train.shape
```




    (4930, 28)




```python
X_test.shape
```




    (2113, 28)




```python
X_train.head()
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>PaperlessBilling</th>
      <th>MonthlyCharges</th>
      <th>TotalCharges</th>
      <th>Contract_One year</th>
      <th>Contract_Two year</th>
      <th>...</th>
      <th>OnlineSecurity_No</th>
      <th>OnlineSecurity_Yes</th>
      <th>OnlineBackup_No</th>
      <th>OnlineBackup_Yes</th>
      <th>DeviceProtection_No</th>
      <th>DeviceProtection_Yes</th>
      <th>TechSupport_No</th>
      <th>TechSupport_Yes</th>
      <th>StreamingTV_No</th>
      <th>StreamingTV_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1695</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>54</td>
      <td>1</td>
      <td>1</td>
      <td>70.70</td>
      <td>3770.00</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1095</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>80.55</td>
      <td>80.55</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3889</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>13</td>
      <td>1</td>
      <td>0</td>
      <td>19.30</td>
      <td>259.65</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3667</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>24</td>
      <td>1</td>
      <td>1</td>
      <td>96.55</td>
      <td>2263.45</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2902</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>6</td>
      <td>1</td>
      <td>1</td>
      <td>74.10</td>
      <td>450.90</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 28 columns</p>
</div>




```python
y_train.head()
```




    1695    0
    1095    0
    3889    0
    3667    0
    2902    0
    Name: Churn, dtype: int64




```python
#normalizing the data i.e standardizing the numbers
from sklearn.preprocessing import StandardScaler
```


```python
SC=StandardScaler()
```


```python
X_train[["tenure","MonthlyCharges","TotalCharges"]]=SC.fit_transform(X_train[["tenure","MonthlyCharges","TotalCharges"]])
X_train.head()
```

    <ipython-input-62-ef26aff8d2de>:1: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      X_train[["tenure","MonthlyCharges","TotalCharges"]]=SC.fit_transform(X_train[["tenure","MonthlyCharges","TotalCharges"]])
    C:\Users\Kulsum\AppData\Roaming\Python\Python38\site-packages\pandas\core\indexing.py:1736: SettingWithCopyWarning: 
    A value is trying to be set on a copy of a slice from a DataFrame.
    Try using .loc[row_indexer,col_indexer] = value instead
    
    See the caveats in the documentation: https://pandas.pydata.org/pandas-docs/stable/user_guide/indexing.html#returning-a-view-versus-a-copy
      isetter(loc, value[:, i].tolist())
    




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>SeniorCitizen</th>
      <th>Partner</th>
      <th>Dependents</th>
      <th>tenure</th>
      <th>PhoneService</th>
      <th>PaperlessBilling</th>
      <th>MonthlyCharges</th>
      <th>TotalCharges</th>
      <th>Contract_One year</th>
      <th>Contract_Two year</th>
      <th>...</th>
      <th>OnlineSecurity_No</th>
      <th>OnlineSecurity_Yes</th>
      <th>OnlineBackup_No</th>
      <th>OnlineBackup_Yes</th>
      <th>DeviceProtection_No</th>
      <th>DeviceProtection_Yes</th>
      <th>TechSupport_No</th>
      <th>TechSupport_Yes</th>
      <th>StreamingTV_No</th>
      <th>StreamingTV_Yes</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1695</th>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0.881078</td>
      <td>1</td>
      <td>1</td>
      <td>0.195927</td>
      <td>0.653409</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1095</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>-1.284263</td>
      <td>1</td>
      <td>1</td>
      <td>0.522755</td>
      <td>-0.976487</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3889</th>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>-0.793997</td>
      <td>1</td>
      <td>0</td>
      <td>-1.509551</td>
      <td>-0.897365</td>
      <td>1</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3667</th>
      <td>1</td>
      <td>1</td>
      <td>1</td>
      <td>-0.344587</td>
      <td>1</td>
      <td>1</td>
      <td>1.053643</td>
      <td>-0.012142</td>
      <td>0</td>
      <td>1</td>
      <td>...</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>1</td>
    </tr>
    <tr>
      <th>2902</th>
      <td>1</td>
      <td>0</td>
      <td>0</td>
      <td>-1.079985</td>
      <td>1</td>
      <td>1</td>
      <td>0.308740</td>
      <td>-0.812876</td>
      <td>0</td>
      <td>0</td>
      <td>...</td>
      <td>0</td>
      <td>1</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
      <td>1</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
<p>5 rows × 28 columns</p>
</div>




```python
sum(data["Churn"])/len(data["Churn"])*100
```




    26.536987079369588




```python
#we have almost 26% churn data
```


```python
import seaborn as sns
```


```python
plt.figure(figsize=(18,10))
sns.heatmap(data.corr(),annot=True)
```




    <AxesSubplot:>




    
![png](output_62_1.png)
    



```python
import statsmodels.api as sm
```


```python
log=sm.GLM(y_train, (sm.add_constant(X_train)),family=sm.families.Binomial())
log.fit().summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>Churn</td>      <th>  No. Observations:  </th>  <td>  4930</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  4907</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    22</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2061.8</td>
</tr>
<tr>
  <th>Date:</th>            <td>Sun, 11 Apr 2021</td> <th>  Deviance:          </th> <td>  4123.7</td>
</tr>
<tr>
  <th>Time:</th>                <td>16:29:40</td>     <th>  Pearson chi2:      </th> <td>5.55e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>         <td>49</td>        <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                    <td></td>                       <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                                 <td>   -0.2684</td> <td>    0.303</td> <td>   -0.887</td> <td> 0.375</td> <td>   -0.861</td> <td>    0.325</td>
</tr>
<tr>
  <th>SeniorCitizen</th>                         <td>    0.2035</td> <td>    0.101</td> <td>    2.023</td> <td> 0.043</td> <td>    0.006</td> <td>    0.401</td>
</tr>
<tr>
  <th>Partner</th>                               <td>    0.0083</td> <td>    0.092</td> <td>    0.090</td> <td> 0.928</td> <td>   -0.172</td> <td>    0.189</td>
</tr>
<tr>
  <th>Dependents</th>                            <td>   -0.1149</td> <td>    0.106</td> <td>   -1.082</td> <td> 0.279</td> <td>   -0.323</td> <td>    0.093</td>
</tr>
<tr>
  <th>tenure</th>                                <td>   -1.3566</td> <td>    0.175</td> <td>   -7.770</td> <td> 0.000</td> <td>   -1.699</td> <td>   -1.014</td>
</tr>
<tr>
  <th>PhoneService</th>                          <td>   -0.6667</td> <td>    0.170</td> <td>   -3.926</td> <td> 0.000</td> <td>   -1.000</td> <td>   -0.334</td>
</tr>
<tr>
  <th>PaperlessBilling</th>                      <td>    0.3110</td> <td>    0.088</td> <td>    3.528</td> <td> 0.000</td> <td>    0.138</td> <td>    0.484</td>
</tr>
<tr>
  <th>MonthlyCharges</th>                        <td>    0.6821</td> <td>    0.286</td> <td>    2.382</td> <td> 0.017</td> <td>    0.121</td> <td>    1.243</td>
</tr>
<tr>
  <th>TotalCharges</th>                          <td>    0.6707</td> <td>    0.185</td> <td>    3.632</td> <td> 0.000</td> <td>    0.309</td> <td>    1.033</td>
</tr>
<tr>
  <th>Contract_One year</th>                     <td>   -0.6137</td> <td>    0.125</td> <td>   -4.916</td> <td> 0.000</td> <td>   -0.858</td> <td>   -0.369</td>
</tr>
<tr>
  <th>Contract_Two year</th>                     <td>   -1.5424</td> <td>    0.215</td> <td>   -7.162</td> <td> 0.000</td> <td>   -1.965</td> <td>   -1.120</td>
</tr>
<tr>
  <th>PaymentMethod_Credit card (automatic)</th> <td>   -0.0729</td> <td>    0.135</td> <td>   -0.539</td> <td> 0.590</td> <td>   -0.338</td> <td>    0.192</td>
</tr>
<tr>
  <th>PaymentMethod_Electronic check</th>        <td>    0.3259</td> <td>    0.111</td> <td>    2.944</td> <td> 0.003</td> <td>    0.109</td> <td>    0.543</td>
</tr>
<tr>
  <th>PaymentMethod_Mailed check</th>            <td>   -0.0502</td> <td>    0.136</td> <td>   -0.370</td> <td> 0.712</td> <td>   -0.316</td> <td>    0.216</td>
</tr>
<tr>
  <th>gender_Male</th>                           <td>   -0.0741</td> <td>    0.077</td> <td>   -0.963</td> <td> 0.336</td> <td>   -0.225</td> <td>    0.077</td>
</tr>
<tr>
  <th>InternetService_Fiber optic</th>           <td>    0.1433</td> <td>    0.264</td> <td>    0.543</td> <td> 0.587</td> <td>   -0.374</td> <td>    0.661</td>
</tr>
<tr>
  <th>InternetService_No</th>                    <td>   -0.0312</td> <td>    0.334</td> <td>   -0.093</td> <td> 0.926</td> <td>   -0.687</td> <td>    0.624</td>
</tr>
<tr>
  <th>MultipleLines_No</th>                      <td>   -0.3938</td> <td>    0.079</td> <td>   -5.014</td> <td> 0.000</td> <td>   -0.548</td> <td>   -0.240</td>
</tr>
<tr>
  <th>MultipleLines_Yes</th>                     <td>   -0.2729</td> <td>    0.118</td> <td>   -2.312</td> <td> 0.021</td> <td>   -0.504</td> <td>   -0.042</td>
</tr>
<tr>
  <th>OnlineSecurity_No</th>                     <td>    0.1663</td> <td>    0.052</td> <td>    3.226</td> <td> 0.001</td> <td>    0.065</td> <td>    0.267</td>
</tr>
<tr>
  <th>OnlineSecurity_Yes</th>                    <td>   -0.4035</td> <td>    0.070</td> <td>   -5.771</td> <td> 0.000</td> <td>   -0.540</td> <td>   -0.266</td>
</tr>
<tr>
  <th>OnlineBackup_No</th>                       <td>    0.0440</td> <td>    0.048</td> <td>    0.919</td> <td> 0.358</td> <td>   -0.050</td> <td>    0.138</td>
</tr>
<tr>
  <th>OnlineBackup_Yes</th>                      <td>   -0.2811</td> <td>    0.067</td> <td>   -4.220</td> <td> 0.000</td> <td>   -0.412</td> <td>   -0.151</td>
</tr>
<tr>
  <th>DeviceProtection_No</th>                   <td>   -0.0578</td> <td>    0.050</td> <td>   -1.156</td> <td> 0.248</td> <td>   -0.156</td> <td>    0.040</td>
</tr>
<tr>
  <th>DeviceProtection_Yes</th>                  <td>   -0.1793</td> <td>    0.071</td> <td>   -2.529</td> <td> 0.011</td> <td>   -0.318</td> <td>   -0.040</td>
</tr>
<tr>
  <th>TechSupport_No</th>                        <td>    0.0936</td> <td>    0.052</td> <td>    1.784</td> <td> 0.074</td> <td>   -0.009</td> <td>    0.197</td>
</tr>
<tr>
  <th>TechSupport_Yes</th>                       <td>   -0.3308</td> <td>    0.072</td> <td>   -4.581</td> <td> 0.000</td> <td>   -0.472</td> <td>   -0.189</td>
</tr>
<tr>
  <th>StreamingTV_No</th>                        <td>   -0.0424</td> <td>    0.063</td> <td>   -0.671</td> <td> 0.502</td> <td>   -0.166</td> <td>    0.081</td>
</tr>
<tr>
  <th>StreamingTV_Yes</th>                       <td>   -0.1948</td> <td>    0.094</td> <td>   -2.068</td> <td> 0.039</td> <td>   -0.379</td> <td>   -0.010</td>
</tr>
</table>



# RFE=Recursive feature elimination technique


```python
from sklearn.linear_model import LogisticRegression
from sklearn.feature_selection import RFE
logreg=LogisticRegression()
```


```python
rfe=RFE(logreg,15)  #getting the top 15 features
rfe.fit(X_train,y_train)
```

    C:\Users\Kulsum\AppData\Roaming\Python\Python38\site-packages\sklearn\utils\validation.py:70: FutureWarning: Pass n_features_to_select=15 as keyword args. From version 1.0 (renaming of 0.25) passing these as positional arguments will result in an error
      warnings.warn(f"Pass {args_msg} as keyword args. From version "
    




    RFE(estimator=LogisticRegression(), n_features_to_select=15)




```python
rfe.support_
```




    array([ True, False, False,  True,  True,  True,  True,  True,  True,
            True, False,  True, False, False,  True, False,  True, False,
            True,  True, False,  True, False, False,  True, False, False,
           False])




```python
list(zip(X_train.columns,rfe.support_,rfe.ranking_))
```




    [('SeniorCitizen', True, 1),
     ('Partner', False, 13),
     ('Dependents', False, 4),
     ('tenure', True, 1),
     ('PhoneService', True, 1),
     ('PaperlessBilling', True, 1),
     ('MonthlyCharges', True, 1),
     ('TotalCharges', True, 1),
     ('Contract_One year', True, 1),
     ('Contract_Two year', True, 1),
     ('PaymentMethod_Credit card (automatic)', False, 10),
     ('PaymentMethod_Electronic check', True, 1),
     ('PaymentMethod_Mailed check', False, 11),
     ('gender_Male', False, 9),
     ('InternetService_Fiber optic', True, 1),
     ('InternetService_No', False, 7),
     ('MultipleLines_No', True, 1),
     ('MultipleLines_Yes', False, 3),
     ('OnlineSecurity_No', True, 1),
     ('OnlineSecurity_Yes', True, 1),
     ('OnlineBackup_No', False, 8),
     ('OnlineBackup_Yes', True, 1),
     ('DeviceProtection_No', False, 12),
     ('DeviceProtection_Yes', False, 6),
     ('TechSupport_No', True, 1),
     ('TechSupport_Yes', False, 2),
     ('StreamingTV_No', False, 14),
     ('StreamingTV_Yes', False, 5)]




```python
col=X_train.columns[rfe.support_]
```


```python
col
```




    Index(['SeniorCitizen', 'tenure', 'PhoneService', 'PaperlessBilling',
           'MonthlyCharges', 'TotalCharges', 'Contract_One year',
           'Contract_Two year', 'PaymentMethod_Electronic check',
           'InternetService_Fiber optic', 'MultipleLines_No', 'OnlineSecurity_No',
           'OnlineSecurity_Yes', 'OnlineBackup_Yes', 'TechSupport_No'],
          dtype='object')




```python
X_train.columns[~rfe.support_]
```




    Index(['Partner', 'Dependents', 'PaymentMethod_Credit card (automatic)',
           'PaymentMethod_Mailed check', 'gender_Male', 'InternetService_No',
           'MultipleLines_Yes', 'OnlineBackup_No', 'DeviceProtection_No',
           'DeviceProtection_Yes', 'TechSupport_Yes', 'StreamingTV_No',
           'StreamingTV_Yes'],
          dtype='object')




```python
X_train_sm=sm.add_constant(X_train[col])
log2=sm.GLM(y_train,X_train_sm,family=sm.families.Binomial())
log2.fit().summary()
```




<table class="simpletable">
<caption>Generalized Linear Model Regression Results</caption>
<tr>
  <th>Dep. Variable:</th>         <td>Churn</td>      <th>  No. Observations:  </th>  <td>  4930</td> 
</tr>
<tr>
  <th>Model:</th>                  <td>GLM</td>       <th>  Df Residuals:      </th>  <td>  4914</td> 
</tr>
<tr>
  <th>Model Family:</th>        <td>Binomial</td>     <th>  Df Model:          </th>  <td>    15</td> 
</tr>
<tr>
  <th>Link Function:</th>         <td>logit</td>      <th>  Scale:             </th> <td>  1.0000</td>
</tr>
<tr>
  <th>Method:</th>                <td>IRLS</td>       <th>  Log-Likelihood:    </th> <td> -2064.0</td>
</tr>
<tr>
  <th>Date:</th>            <td>Sun, 11 Apr 2021</td> <th>  Deviance:          </th> <td>  4128.0</td>
</tr>
<tr>
  <th>Time:</th>                <td>16:30:37</td>     <th>  Pearson chi2:      </th> <td>5.56e+03</td>
</tr>
<tr>
  <th>No. Iterations:</th>          <td>7</td>        <th>                     </th>     <td> </td>   
</tr>
<tr>
  <th>Covariance Type:</th>     <td>nonrobust</td>    <th>                     </th>     <td> </td>   
</tr>
</table>
<table class="simpletable">
<tr>
                 <td></td>                   <th>coef</th>     <th>std err</th>      <th>z</th>      <th>P>|z|</th>  <th>[0.025</th>    <th>0.975]</th>  
</tr>
<tr>
  <th>const</th>                          <td>   -1.0271</td> <td>    0.378</td> <td>   -2.715</td> <td> 0.007</td> <td>   -1.768</td> <td>   -0.286</td>
</tr>
<tr>
  <th>SeniorCitizen</th>                  <td>    0.2246</td> <td>    0.098</td> <td>    2.281</td> <td> 0.023</td> <td>    0.032</td> <td>    0.418</td>
</tr>
<tr>
  <th>tenure</th>                         <td>   -1.3654</td> <td>    0.172</td> <td>   -7.947</td> <td> 0.000</td> <td>   -1.702</td> <td>   -1.029</td>
</tr>
<tr>
  <th>PhoneService</th>                   <td>   -0.7045</td> <td>    0.204</td> <td>   -3.460</td> <td> 0.001</td> <td>   -1.104</td> <td>   -0.305</td>
</tr>
<tr>
  <th>PaperlessBilling</th>               <td>    0.3115</td> <td>    0.088</td> <td>    3.544</td> <td> 0.000</td> <td>    0.139</td> <td>    0.484</td>
</tr>
<tr>
  <th>MonthlyCharges</th>                 <td>    0.3994</td> <td>    0.163</td> <td>    2.457</td> <td> 0.014</td> <td>    0.081</td> <td>    0.718</td>
</tr>
<tr>
  <th>TotalCharges</th>                   <td>    0.6731</td> <td>    0.184</td> <td>    3.668</td> <td> 0.000</td> <td>    0.313</td> <td>    1.033</td>
</tr>
<tr>
  <th>Contract_One year</th>              <td>   -0.6285</td> <td>    0.124</td> <td>   -5.053</td> <td> 0.000</td> <td>   -0.872</td> <td>   -0.385</td>
</tr>
<tr>
  <th>Contract_Two year</th>              <td>   -1.5657</td> <td>    0.215</td> <td>   -7.293</td> <td> 0.000</td> <td>   -1.986</td> <td>   -1.145</td>
</tr>
<tr>
  <th>PaymentMethod_Electronic check</th> <td>    0.3714</td> <td>    0.082</td> <td>    4.538</td> <td> 0.000</td> <td>    0.211</td> <td>    0.532</td>
</tr>
<tr>
  <th>InternetService_Fiber optic</th>    <td>    0.3888</td> <td>    0.178</td> <td>    2.189</td> <td> 0.029</td> <td>    0.041</td> <td>    0.737</td>
</tr>
<tr>
  <th>MultipleLines_No</th>               <td>   -0.1702</td> <td>    0.099</td> <td>   -1.726</td> <td> 0.084</td> <td>   -0.363</td> <td>    0.023</td>
</tr>
<tr>
  <th>OnlineSecurity_No</th>              <td>    0.0864</td> <td>    0.257</td> <td>    0.336</td> <td> 0.737</td> <td>   -0.417</td> <td>    0.590</td>
</tr>
<tr>
  <th>OnlineSecurity_Yes</th>             <td>   -0.4391</td> <td>    0.281</td> <td>   -1.565</td> <td> 0.118</td> <td>   -0.989</td> <td>    0.111</td>
</tr>
<tr>
  <th>OnlineBackup_Yes</th>               <td>   -0.2807</td> <td>    0.094</td> <td>   -2.986</td> <td> 0.003</td> <td>   -0.465</td> <td>   -0.096</td>
</tr>
<tr>
  <th>TechSupport_No</th>                 <td>    0.3824</td> <td>    0.107</td> <td>    3.570</td> <td> 0.000</td> <td>    0.172</td> <td>    0.592</td>
</tr>
</table>




```python
y_train_pred=log2.fit().predict(X_train_sm)
y_train_pred[:10]
#greater than 0.5=churn customer 
```




    1695    0.071999
    1095    0.719864
    3889    0.065800
    3667    0.305942
    2902    0.595941
    1630    0.611671
    4294    0.295856
    1881    0.214443
    4710    0.095329
    1612    0.123288
    dtype: float64




```python
y_train_pred_final=pd.DataFrame({"Churn": y_train.values,"Churn_prob":y_train_pred})
y_train_pred_final['CustID']=y_train.index
```


```python
y_train_pred_final
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Churn</th>
      <th>Churn_prob</th>
      <th>CustID</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1695</th>
      <td>0</td>
      <td>0.071999</td>
      <td>1695</td>
    </tr>
    <tr>
      <th>1095</th>
      <td>0</td>
      <td>0.719864</td>
      <td>1095</td>
    </tr>
    <tr>
      <th>3889</th>
      <td>0</td>
      <td>0.065800</td>
      <td>3889</td>
    </tr>
    <tr>
      <th>3667</th>
      <td>0</td>
      <td>0.305942</td>
      <td>3667</td>
    </tr>
    <tr>
      <th>2902</th>
      <td>0</td>
      <td>0.595941</td>
      <td>2902</td>
    </tr>
    <tr>
      <th>...</th>
      <td>...</td>
      <td>...</td>
      <td>...</td>
    </tr>
    <tr>
      <th>3772</th>
      <td>1</td>
      <td>0.648860</td>
      <td>3772</td>
    </tr>
    <tr>
      <th>5191</th>
      <td>0</td>
      <td>0.054261</td>
      <td>5191</td>
    </tr>
    <tr>
      <th>5226</th>
      <td>0</td>
      <td>0.223116</td>
      <td>5226</td>
    </tr>
    <tr>
      <th>5390</th>
      <td>1</td>
      <td>0.787241</td>
      <td>5390</td>
    </tr>
    <tr>
      <th>860</th>
      <td>0</td>
      <td>0.035133</td>
      <td>860</td>
    </tr>
  </tbody>
</table>
<p>4930 rows × 3 columns</p>
</div>




```python
#Create new cil with 1 uf churn prob is greater than 0.5 else 0
```


```python
y_train_pred_final["Predicted"]=y_train_pred_final.Churn_prob.map(lambda X: 1 if X>0.5 else 0)
```


```python
y_train_pred_final.head(10)
```




<div>
<style scoped>
    .dataframe tbody tr th:only-of-type {
        vertical-align: middle;
    }

    .dataframe tbody tr th {
        vertical-align: top;
    }

    .dataframe thead th {
        text-align: right;
    }
</style>
<table border="1" class="dataframe">
  <thead>
    <tr style="text-align: right;">
      <th></th>
      <th>Churn</th>
      <th>Churn_prob</th>
      <th>CustID</th>
      <th>Predicted</th>
    </tr>
  </thead>
  <tbody>
    <tr>
      <th>1695</th>
      <td>0</td>
      <td>0.071999</td>
      <td>1695</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1095</th>
      <td>0</td>
      <td>0.719864</td>
      <td>1095</td>
      <td>1</td>
    </tr>
    <tr>
      <th>3889</th>
      <td>0</td>
      <td>0.065800</td>
      <td>3889</td>
      <td>0</td>
    </tr>
    <tr>
      <th>3667</th>
      <td>0</td>
      <td>0.305942</td>
      <td>3667</td>
      <td>0</td>
    </tr>
    <tr>
      <th>2902</th>
      <td>0</td>
      <td>0.595941</td>
      <td>2902</td>
      <td>1</td>
    </tr>
    <tr>
      <th>1630</th>
      <td>0</td>
      <td>0.611671</td>
      <td>1630</td>
      <td>1</td>
    </tr>
    <tr>
      <th>4294</th>
      <td>0</td>
      <td>0.295856</td>
      <td>4294</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1881</th>
      <td>0</td>
      <td>0.214443</td>
      <td>1881</td>
      <td>0</td>
    </tr>
    <tr>
      <th>4710</th>
      <td>0</td>
      <td>0.095329</td>
      <td>4710</td>
      <td>0</td>
    </tr>
    <tr>
      <th>1612</th>
      <td>1</td>
      <td>0.123288</td>
      <td>1612</td>
      <td>0</td>
    </tr>
  </tbody>
</table>
</div>




```python
from sklearn.metrics import accuracy_score,confusion_matrix
```


```python
confusion_matrix(y_train_pred_final.Churn,y_train_pred_final.Predicted)
```




    array([[3274,  361],
           [ 600,  695]], dtype=int64)



pred vs actual
          not_churn         churn
pred-->
actual   3274               361         not_churn
         600                695          churn



```python
accuracy_score(y_train_pred_final.Churn,y_train_pred_final.Predicted)*100
```




    80.50709939148074




```python

```
